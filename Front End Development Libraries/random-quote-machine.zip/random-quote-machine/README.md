# Random Quote Machine

A Pen created on CodePen.io. Original URL: [https://codepen.io/ricardobar96/pen/YzvjXxy](https://codepen.io/ricardobar96/pen/YzvjXxy).

